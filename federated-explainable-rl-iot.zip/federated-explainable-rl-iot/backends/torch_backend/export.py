import argparse, torch, os
from models.rl_dqn import DQN
from models.classifier_head import ClassifierHead

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--checkpoint", required=True)
    ap.add_argument("--format", choices=["onnx","torchscript"], default="onnx")
    ap.add_argument("--out", default="artifacts/model.onnx")
    args = ap.parse_args()

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    dummy = torch.randn(1,64)
    policy = DQN(64, 3)
    clf = ClassifierHead(64, 2)
    ckpt = torch.load(args.checkpoint, map_location="cpu")
    policy.load_state_dict(ckpt["policy"]); clf.load_state_dict(ckpt["clf"])
    model = torch.jit.trace(lambda x: clf(x), dummy)

    if args.format == "onnx":
        import onnx
        torch.onnx.export(clf, dummy, args.out, input_names=["input"], output_names=["logits"], opset_version=13)
        print("Exported ONNX to", args.out)
    else:
        ts_path = args.out if args.out.endswith(".pt") else args.out + ".pt"
        model.save(ts_path)
        print("Exported TorchScript to", ts_path)
