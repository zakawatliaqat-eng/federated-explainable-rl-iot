import os, argparse, torch
from torch.utils.data import DataLoader, TensorDataset
from models.rl_dqn import DQN
from models.classifier_head import ClassifierHead

def load_dummy(n=2000, d=64, k=2):
    x = torch.randn(n, d)
    y = (x[:, 0] + 0.5 * x[:, 1] > 0).long()
    return TensorDataset(x, y), d, k

def train(args):
    ds, in_dim, num_classes = load_dummy()
    dl = DataLoader(ds, batch_size=args.batch_size, shuffle=True)
    device = "cuda" if torch.cuda.is_available() else "cpu"

    policy = DQN(in_dim, action_dim=3).to(device)
    clf = ClassifierHead(in_dim, num_classes).to(device)
    opt = torch.optim.Adam(list(policy.parameters())+list(clf.parameters()), lr=args.lr)
    ce = torch.nn.CrossEntropyLoss()

    for epoch in range(args.epochs):
        for xb, yb in dl:
            xb, yb = xb.to(device), yb.to(device)
            q = policy(xb)
            logits = clf(xb)
            rl_loss = q.mean() * 0.0  # placeholder for RL loss
            sup_loss = ce(logits, yb)
            loss = sup_loss + rl_loss
            opt.zero_grad(); loss.backward(); opt.step()
        print(f"epoch {epoch+1} loss {loss.item():.4f}")

    os.makedirs(args.save_dir, exist_ok=True)
    torch.save({"policy": policy.state_dict(), "clf": clf.state_dict()}, os.path.join(args.save_dir, "best.pt"))
    print("Saved", os.path.join(args.save_dir, "best.pt"))

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--epochs", type=int, default=3)
    p.add_argument("--batch_size", type=int, default=256)
    p.add_argument("--lr", type=float, default=1e-3)
    p.add_argument("--save_dir", type=str, default="outputs/torch_centralized")
    args = p.parse_args()
    train(args)
