import torch
import torch.nn as nn

class DQN(nn.Module):
    def __init__(self, state_dim, action_dim):
        super().__init__()
        self.q = nn.Sequential(
            nn.Linear(state_dim, 256),
            nn.ReLU(),
            nn.Linear(256, action_dim)
        )
    def forward(self, s):
        return self.q(s)
    def act(self, s, eps=0.1):
        if torch.rand(1).item() < eps:
            return torch.randint(0, self.q[-1].out_features, (1,)).item()
        with torch.no_grad():
            return torch.argmax(self.forward(s)).item()
