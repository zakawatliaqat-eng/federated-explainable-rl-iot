import argparse, tensorflow as tf, os

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--checkpoint", required=True)
    ap.add_argument("--format", choices=["savedmodel","tflite"], default="tflite")
    ap.add_argument("--quant", choices=["none","float16"], default="float16")
    ap.add_argument("--out", default="artifacts/model.tflite")
    args = ap.parse_args()

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    model = tf.keras.models.load_model(args.checkpoint)

    if args.format == "savedmodel":
        tf.saved_model.save(model, args.out)
        print("Exported SavedModel to", args.out)
    else:
        converter = tf.lite.TFLiteConverter.from_keras_model(model)
        if args.quant == "float16":
            converter.optimizations = [tf.lite.Optimize.DEFAULT]
            converter.target_spec.supported_types = [tf.float16]
        tflite_model = converter.convert()
        with open(args.out, "wb") as f:
            f.write(tflite_model)
        print("Exported TFLite to", args.out)
