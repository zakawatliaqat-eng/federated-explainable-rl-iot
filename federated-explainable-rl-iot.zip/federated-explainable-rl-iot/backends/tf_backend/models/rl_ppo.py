import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers

def build_ppo(state_dim, action_dim):
    inp = keras.Input(shape=(state_dim,))
    x = layers.Dense(256, activation='relu')(inp)
    pi = layers.Dense(action_dim)(x)
    v  = layers.Dense(1)(x)
    return keras.Model(inp, [pi, v])
