import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers

def build_classifier(in_dim, num_classes):
    inp = keras.Input(shape=(in_dim,))
    x = layers.Dense(256, activation='relu')(inp)
    out = layers.Dense(num_classes)(x)
    return keras.Model(inp, out)
