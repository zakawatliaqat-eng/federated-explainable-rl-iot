import os, argparse, numpy as np, tensorflow as tf
from models.classifier_head import build_classifier  # noqa: E402

def load_dummy(n=2000, d=64, k=2):
    x = np.random.randn(n, d).astype('float32')
    y = ((x[:,0] + 0.5*x[:,1]) > 0).astype('int32')
    return (x, y), d, k

def train(args):
    (x, y), in_dim, num_classes = load_dummy()
    model = build_classifier(in_dim, num_classes)
    model.compile(optimizer=tf.keras.optimizers.Adam(args.lr),
                  loss=tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True),
                  metrics=['accuracy'])
    model.fit(x, y, epochs=args.epochs, batch_size=args.batch_size, verbose=2)
    os.makedirs(args.save_dir, exist_ok=True)
    model.save(args.save_dir + "/best")
    print("Saved", args.save_dir + "/best")

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--epochs", type=int, default=3)
    p.add_argument("--batch_size", type=int, default=256)
    p.add_argument("--lr", type=float, default=1e-3)
    p.add_argument("--save_dir", type=str, default="outputs/tf_centralized")
    args = p.parse_args()
    train(args)
