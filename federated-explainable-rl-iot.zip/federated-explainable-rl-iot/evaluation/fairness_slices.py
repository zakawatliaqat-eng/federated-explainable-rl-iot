import numpy as np
def worst_group_gap(scores_by_group):
    groups = list(scores_by_group.keys())
    vals = [np.mean(v) for v in scores_by_group.values()]
    return float(max(vals) - min(vals)), dict(zip(groups, vals))
