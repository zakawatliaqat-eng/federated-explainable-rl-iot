# Placeholder for CIC-IDS2017 dataset loader. Replace with real parsing.
def load():
    raise NotImplementedError("Implement CIC-IDS2017 loader.")
