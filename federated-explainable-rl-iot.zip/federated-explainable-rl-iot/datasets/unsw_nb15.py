# Placeholder for UNSW-NB15 dataset loader. Replace with real parsing.
def load():
    raise NotImplementedError("Implement UNSW-NB15 loader.")
