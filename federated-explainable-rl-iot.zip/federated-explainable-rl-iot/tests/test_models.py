def test_models_smoke():
    assert 1 + 1 == 2
