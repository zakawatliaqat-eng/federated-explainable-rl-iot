def test_end_to_end():
    assert 'ok' == 'ok'
