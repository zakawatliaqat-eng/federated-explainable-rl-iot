Repository Name:
federated-explainable-rl-iot

One-line Summary:
Federated Explainable Reinforcement Learning (XRL) for IoT Threat Detection with PyTorch and TensorFlow backends. Includes centralized and federated training (FedAvg), explainability (SHAP, Integrated Gradients, LIME), and evaluation on popular intrusion datasets.

Badges (replace main with your default branch if needed):
[![CI](https://github.com/zakawatliaqat-eng/federated-explainable-rl-iot/actions/workflows/ci.yml/badge.svg)](https://github.com/zakawatliaqat-eng/federated-explainable-rl-iot/actions)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)
[![Python](https://img.shields.io/badge/Python-3.10%2B-blue)]()
[![Frameworks](https://img.shields.io/badge/Frameworks-PyTorch%20%7C%20TensorFlow-blueviolet)]()

Overview:
This repository implements a research-grade pipeline for IoT network threat detection using reinforcement learning agents and supervised heads, trained in both centralized and federated settings. The goal is to (1) detect intrusions and anomalous flows in IoT networks, (2) preserve data locality via federated averaging, and (3) produce faithful, human-interpretable explanations for model decisions. The codebase offers mirrored functionality in PyTorch and TensorFlow, making it suitable for reproducibility, benchmarking, and deployment.

Key Features:
1) Dual Backends: PyTorch and TensorFlow implementations with matching APIs.
2) Federated Learning: FedAvg via Flower; configurable client heterogeneity (data, compute, connectivity).
3) RL Agents: DQN and PPO baselines for sequential decision policies (e.g., adaptive feature selection, thresholding, or active defense action space).
4) Hybrid Training: RL policy with an auxiliary supervised classifier head for robust detection.
5) Explainability (XAI): SHAP (Tree/Deep), Integrated Gradients, LIME; per-sample and global importance reports.
6) Datasets: Ready loaders for CIC-IDS2017 and UNSW-NB15 (you place data locally). CSV/Parquet supported.
7) Reproducibility: Deterministic seeds, Hydra configs, Dockerfiles, CI checks.
8) Metrics: Accuracy, F1, ROC-AUC, Precision-Recall AUC; RL returns, cost-aware policies; fairness slices by device/site.
9) Export: ONNX and TorchScript (PyTorch), SavedModel and TFLite (TensorFlow). Optional quantization.
10) Deployment: Minimal FastAPI inference service with batched scoring and explanation endpoints.

Repository Structure:
.
├── backends
│   ├── torch_backend
│   │   ├── models
│   │   │   ├── rl_dqn.py
│   │   │   ├── rl_ppo.py
│   │   │   └── classifier_head.py
│   │   ├── train_centralized.py
│   │   ├── train_federated.py
│   │   ├── explain.py
│   │   └── export.py
│   └── tf_backend
│       ├── models
│       │   ├── rl_dqn.py
│       │   ├── rl_ppo.py
│       │   └── classifier_head.py
│       ├── train_centralized.py
│       ├── train_federated.py
│       ├── explain.py
│       └── export.py
├── federated
│   ├── flower_server.py
│   ├── flower_client_torch.py
│   └── flower_client_tf.py
├── data
│   ├── README_DATA.txt
│   └── (place datasets here)
├── configs
│   ├── default.yaml
│   ├── torch.yaml
│   └── tf.yaml
├── datasets
│   ├── cicids2017.py
│   └── unsw_nb15.py
├── evaluation
│   ├── metrics.py
│   └── fairness_slices.py
├── deployment
│   ├── fastapi_app.py
│   ├── requirements.txt
│   └── Dockerfile
├── scripts
│   ├── prepare_cicids2017.sh
│   ├── prepare_unsw_nb15.sh
│   ├── run_torch_centralized.sh
│   ├── run_tf_centralized.sh
│   ├── run_federated_torch.sh
│   ├── run_federated_tf.sh
│   └── explain_sample.sh
├── tests
│   ├── test_loaders.py
│   ├── test_models.py
│   └── test_end_to_end.py
├── .github
│   └── workflows
│       └── ci.yml
├── requirements_torch.txt
├── requirements_tf.txt
├── environment.yml
├── LICENSE
└── README.md  (this file)

IoT Threat Model (example):
Actions: drop, allow, rate-limit, isolate device, request verification, escalate.
States: recent flow features, device metadata, historical decisions, queue length.
Rewards: +TP for blocking malicious, −FP penalty for blocking benign, small step cost, optional fairness regularizer.

Installation:
Option A: PyTorch stack
python -m venv .venv && . .venv/bin/activate  (Linux/macOS)
or .venv\Scripts\activate  (Windows)
pip install -r requirements_torch.txt

Option B: TensorFlow stack
python -m venv .venv && . .venv/bin/activate  (Linux/macOS)
or .venv\Scripts\activate  (Windows)
pip install -r requirements_tf.txt

Optional: Conda
conda env create -f environment.yml
conda activate ferlit

Datasets:
1) CIC-IDS2017: download CSVs to data/cicids2017 and run scripts/prepare_cicids2017.sh
2) UNSW-NB15: download to data/unsw_nb15 and run scripts/prepare_unsw_nb15.sh
The loaders handle standard splits; you can configure non-IID splits per client.

Quick Start (Centralized, PyTorch):
python backends/torch_backend/train_centralized.py --epochs 3 --batch_size 256 --lr 1e-3 --save_dir outputs/torch_centralized

Quick Start (Centralized, TensorFlow):
python backends/tf_backend/train_centralized.py --epochs 3 --batch_size 256 --lr 1e-3 --save_dir outputs/tf_centralized

Federated Training (Flower, PyTorch):
# Terminal 1: server
python federated/flower_server.py
# Terminal 2..N: clients
python federated/flower_client_torch.py

Federated Training (Flower, TensorFlow):
# Server
python federated/flower_server.py
# Clients
python federated/flower_client_tf.py

Explainability (examples):
python backends/torch_backend/explain.py --checkpoint outputs/torch_centralized/best.pt --out_dir outputs/explain/torch
python backends/tf_backend/explain.py --checkpoint outputs/tf_centralized/best --out_dir outputs/explain/tf

Exports:
PyTorch to ONNX:
python backends/torch_backend/export.py --checkpoint outputs/torch_centralized/best.pt --format onnx --out artifacts/model.onnx

TensorFlow to TFLite (float16):
python backends/tf_backend/export.py --checkpoint outputs/tf_centralized/best --format tflite --quant float16 --out artifacts/model.tflite

API Inference (FastAPI):
pip install -r deployment/requirements.txt
uvicorn deployment.fastapi_app:app --host 0.0.0.0 --port 8000
Endpoints:
POST /predict    -> batch intrusion predictions
POST /explain    -> per-record feature attributions

Configuration (Hydra-style keys):
dataset: cicids2017 | unsw_nb15 | custom_csv
model: dqn | ppo
aux_classifier: true | false
non_iid: true | false (federated)
rounds, local_epochs, batch_size, lr, gamma, epsilon, clip_range, entropy_coef
explain.method: shap | ig | lime
export.format: onnx | torchscript | savedmodel | tflite

Reproducibility:
Set seeds via config: seed=42
All dataloaders and client splits use seeded generators.
CI runs a tiny smoke test on synthetic data.

Research Protocol (default):
1) Centralized training on CIC-IDS2017 and UNSW-NB15; report ROC-AUC, F1, PR-AUC.
2) Federated training with K=5 clients, non-IID Dirichlet alpha=0.3; compare against centralized.
3) RL ablation: purely supervised vs hybrid RL+supervised; DQN vs PPO.
4) XAI evaluation: stability of attributions across clients; agreement with known attack features.
5) Fairness slices: device type, site, traffic volume; report worst-group gap in F1.

Cite This Repository (BibTeX template):
@software{zakawatliaqat-eng_fedxrl_iot_2025,
  author  = {Zakawat Liaqat},
  title   = {Federated Explainable Reinforcement Learning for IoT Threat Detection},
  year    = {2025},
  url     = {https://github.com/zakawatliaqat-eng/federated-explainable-rl-iot}
}

Contributing:
Pull requests are welcome. Please open an issue first for significant changes.
Coding style: black/ruff (PyTorch), yapf/flake8 (TensorFlow). See tests/ for unit coverage.

Security:
This code is for research. Do not deploy directly to production networks without thorough validation, threat modeling, and compliance checks.

License:
MIT License (default). You can change to Apache-2.0 or GPL-3.0 if your collaborators require it. Update the LICENSE file and the badge above accordingly.

Maintainer:
zakawatliaqat-eng
