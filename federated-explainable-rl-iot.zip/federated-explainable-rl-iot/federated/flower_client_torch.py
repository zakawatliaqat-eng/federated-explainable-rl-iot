import flwr as fl, torch
from torch.utils.data import DataLoader, TensorDataset
from backends.torch_backend.models.classifier_head import ClassifierHead

def get_data(n=400, d=64):
    x = torch.randn(n, d)
    y = (x[:, 0] + 0.5 * x[:, 1] > 0).long()
    return TensorDataset(x, y)

class TorchClient(fl.client.NumPyClient):
    def __init__(self):
        self.model = ClassifierHead(64, 2)
        self.opt = torch.optim.Adam(self.model.parameters(), lr=1e-3)
        self.loss = torch.nn.CrossEntropyLoss()
        self.trainloader = DataLoader(get_data(), batch_size=128, shuffle=True)
        self.testloader  = DataLoader(get_data(200), batch_size=128)

    def get_parameters(self, config):
        return [v.detach().numpy() for v in self.model.state_dict().values()]

    def set_parameters(self, parameters):
        state = dict(zip(self.model.state_dict().keys(), [torch.tensor(p) for p in parameters]))
        self.model.load_state_dict(state, strict=True)

    def fit(self, parameters, config):
        self.set_parameters(parameters)
        self.model.train()
        for xb, yb in self.trainloader:
            self.opt.zero_grad()
            logits = self.model(xb)
            loss = self.loss(logits, yb)
            loss.backward(); self.opt.step()
        return self.get_parameters({}), len(self.trainloader.dataset), {}

    def evaluate(self, parameters, config):
        self.set_parameters(parameters)
        correct = total = 0
        self.model.eval()
        with torch.no_grad():
            for xb, yb in self.testloader:
                pred = self.model(xb).argmax(1)
                correct += (pred == yb).sum().item()
                total += yb.size(0)
        acc = correct / total
        return float(1.0 - acc), total, {"acc": acc}

def main():
    fl.client.start_numpy_client(server_address="127.0.0.1:8080", client=TorchClient())

if __name__ == "__main__":
    main()
