import flwr as fl
import numpy as np
import tensorflow as tf
from tensorflow import keras
from backends.tf_backend.models.classifier_head import build_classifier

def get_data(n=400, d=64):
    x = np.random.randn(n, d).astype('float32')
    y = ((x[:,0] + 0.5*x[:,1]) > 0).astype('int32')
    return x, y

class TFClient(fl.client.NumPyClient):
    def __init__(self):
        self.model = build_classifier(64, 2)
        self.model.compile(optimizer=keras.optimizers.Adam(1e-3),
                           loss=keras.losses.SparseCategoricalCrossentropy(from_logits=True),
                           metrics=['accuracy'])
        x, y = get_data()
        self.x_train, self.y_train = x, y
        self.x_test,  self.y_test  = get_data(200)

    def get_parameters(self, config):
        return self.model.get_weights()

    def set_parameters(self, parameters):
        self.model.set_weights(parameters)

    def fit(self, parameters, config):
        self.set_parameters(parameters)
        self.model.fit(self.x_train, self.y_train, epochs=1, batch_size=128, verbose=0)
        return self.get_parameters({}), len(self.x_train), {}

    def evaluate(self, parameters, config):
        self.set_parameters(parameters)
        loss, acc = self.model.evaluate(self.x_test, self.y_test, verbose=0)
        return float(loss), len(self.x_test), {"acc": float(acc)}

def main():
    fl.client.start_numpy_client(server_address="127.0.0.1:8080", client=TFClient())

if __name__ == "__main__":
    main()
