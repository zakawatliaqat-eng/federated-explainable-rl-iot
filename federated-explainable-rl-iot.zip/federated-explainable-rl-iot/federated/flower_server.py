import flwr as fl
from flwr.server.strategy import FedAvg

def main():
    strategy = FedAvg()
    fl.server.start_server(server_address="0.0.0.0:8080",
                           strategy=strategy,
                           config=fl.server.ServerConfig(num_rounds=5))

if __name__ == "__main__":
    main()
