from fastapi import FastAPI
from pydantic import BaseModel
from typing import List
import numpy as np

app = FastAPI(title="Federated XRL IoT Inference API")

class PredictRequest(BaseModel):
    records: List[List[float]]

class PredictResponse(BaseModel):
    logits: List[List[float]]

@app.post("/predict", response_model=PredictResponse)
def predict(req: PredictRequest):
    X = np.array(req.records, dtype=float)
    logits = np.random.randn(X.shape[0], 2).tolist()  # placeholder
    return PredictResponse(logits=logits)

class ExplainRequest(BaseModel):
    records: List[List[float]]
    method: str = "shap"

@app.post("/explain")
def explain(req: ExplainRequest):
    X = np.array(req.records, dtype=float)
    attributions = np.random.randn(X.shape[0], X.shape[1]).tolist()  # placeholder
    return {"method": req.method, "attributions": attributions}
