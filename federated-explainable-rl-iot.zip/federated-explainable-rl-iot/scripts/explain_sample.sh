#!/usr/bin/env bash
python backends/torch_backend/explain.py --checkpoint outputs/torch_centralized/best.pt
