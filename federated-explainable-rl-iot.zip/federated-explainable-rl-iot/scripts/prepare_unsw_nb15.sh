#!/usr/bin/env bash
set -euo pipefail
echo 'Place UNSW-NB15 CSVs under data/unsw_nb15'
