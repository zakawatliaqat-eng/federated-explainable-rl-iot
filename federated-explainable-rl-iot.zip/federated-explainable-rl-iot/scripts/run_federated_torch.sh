#!/usr/bin/env bash
python federated/flower_server.py & sleep 2 && python federated/flower_client_torch.py
