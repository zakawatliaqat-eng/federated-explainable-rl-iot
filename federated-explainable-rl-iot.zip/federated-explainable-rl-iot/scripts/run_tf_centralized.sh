#!/usr/bin/env bash
python backends/tf_backend/train_centralized.py
