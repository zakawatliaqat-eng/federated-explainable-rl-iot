#!/usr/bin/env bash
set -euo pipefail
echo 'Place CIC-IDS2017 CSVs under data/cicids2017'
