#!/usr/bin/env bash
python backends/torch_backend/train_centralized.py
